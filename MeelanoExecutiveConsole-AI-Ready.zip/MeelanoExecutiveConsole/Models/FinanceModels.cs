namespace MeelanoExecutiveConsole.Models;
public enum CheckKind { دریافتی, پرداختی }
public sealed class CheckItem { public string Number {get;set;}=""; public CheckKind Kind {get;set;} public string Party {get;set;}=""; public decimal Amount {get;set;} public DateTime DueDate {get;set;} public string Status {get;set;}="در انتظار"; public int Risk {get;set;} public string Bank {get;set;}=""; }
public sealed class SaleItem { public DateTime Date {get;set;} public string Customer {get;set;}=""; public decimal Amount {get;set;} public decimal Profit {get;set;} public string CollectionStatus {get;set;}=""; public string Seller {get;set;}=""; }
