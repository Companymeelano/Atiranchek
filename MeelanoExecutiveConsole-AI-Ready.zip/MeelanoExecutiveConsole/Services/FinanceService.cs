using MeelanoExecutiveConsole.Models;
namespace MeelanoExecutiveConsole.Services;
public sealed class FinanceService(IRepository repository) {
 public IReadOnlyList<CheckItem> Checks=>repository.GetChecks(); public IReadOnlyList<SaleItem> Sales=>repository.GetSales();
 public decimal Incoming(DateTime from,DateTime to)=>Checks.Where(x=>x.Kind==CheckKind.دریافتی&&x.Status!="وصول‌شده"&&x.DueDate.Date>=from.Date&&x.DueDate.Date<=to.Date).Sum(x=>x.Amount);
 public decimal Outgoing(DateTime from,DateTime to)=>Checks.Where(x=>x.Kind==CheckKind.پرداختی&&x.Status!="پرداخت‌شده"&&x.DueDate.Date>=from.Date&&x.DueDate.Date<=to.Date).Sum(x=>x.Amount);
 public decimal Net7=>Incoming(DateTime.Today,DateTime.Today.AddDays(7))-Outgoing(DateTime.Today,DateTime.Today.AddDays(7));
 public IReadOnlyList<(DateTime Day,decimal In,decimal Out,decimal Gap)> Radar(){decimal gap=0;return Enumerable.Range(0,30).Select(i=>{var d=DateTime.Today.AddDays(i);var a=Incoming(d,d);var b=Outgoing(d,d);gap+=a-b;return(d,a,b,gap);}).ToList();}
 public (DateTime? Date,decimal Amount) WeightedDate(IEnumerable<CheckItem> items){var a=items.Where(x=>x.Status!="وصول‌شده").ToList();var total=a.Sum(x=>x.Amount);return total==0?(null,0):(DateTime.Today.AddDays((double)a.Sum(x=>x.Amount*(decimal)(x.DueDate.Date-DateTime.Today).TotalDays)/ (double)total),total);}
}
