using System.Text;
using System.Windows;
using MeelanoExecutiveConsole.Models;
using MeelanoExecutiveConsole.ViewModels;

namespace MeelanoExecutiveConsole.Views;

public partial class MainWindow : Window
{
    readonly MainViewModel vm = new();

    public MainWindow()
    {
        InitializeComponent();
        DataContext = vm;
        ChecksGrid.SelectionChanged += (_, _) => vm.Notify();
    }

    void Set(string status)
    {
        foreach (CheckItem c in ChecksGrid.SelectedItems)
            c.Status = status;
        vm.Notify();
        ChecksGrid.Items.Refresh();
    }

    void Collect_Click(object s, RoutedEventArgs e) => Set("وصول‌شده");
    void Pay_Click(object s, RoutedEventArgs e) => Set("پرداخت‌شده");
    void Return_Click(object s, RoutedEventArgs e) => Set("برگشتی");
    void Suspend_Click(object s, RoutedEventArgs e) => Set("معلق");
    void Shift_ValueChanged(object s, System.Windows.RoutedPropertyChangedEventArgs<double> e) { if (vm is not null) vm.Notify(); }

    static void Export(string path, string content)
    {
        System.IO.File.WriteAllText(path, "\uFEFF" + content, new UTF8Encoding(true));
        MessageBox.Show("فایل ذخیره شد:\n" + path, "خروجی CSV");
    }

    void ChecksCsv_Click(object s, RoutedEventArgs e)
    {
        var d = new Microsoft.Win32.SaveFileDialog { Filter = "CSV|*.csv", FileName = "checks.csv" };
        if (d.ShowDialog() == true)
            Export(d.FileName, "شماره,نوع,طرف حساب,مبلغ,سررسید,وضعیت,ریسک\n" + string.Join("\n", vm.Checks.Select(x => $"{x.Number},{x.Kind},{x.Party},{x.Amount},{x.DueDate:yyyy-MM-dd},{x.Status},{x.Risk}")));
    }

    void SalesCsv_Click(object s, RoutedEventArgs e)
    {
        var d = new Microsoft.Win32.SaveFileDialog { Filter = "CSV|*.csv", FileName = "sales.csv" };
        if (d.ShowDialog() == true)
            Export(d.FileName, "تاریخ,مشتری,فروشنده,مبلغ,سود,وضعیت وصول\n" + string.Join("\n", vm.Sales.Select(x => $"{x.Date:yyyy-MM-dd},{x.Customer},{x.Seller},{x.Amount},{x.Profit},{x.CollectionStatus}")));
    }

    void Print_Click(object s, RoutedEventArgs e)
    {
        var lines = vm.Checks.Select(x => $"{x.Number} | {x.Party} | {x.Amount:N0} | {x.DueDate:yyyy/MM/dd} | {x.Status}");
        var para = new System.Windows.Documents.Paragraph(new System.Windows.Documents.Run(string.Join("\n", lines)));
        var doc = new System.Windows.Documents.FlowDocument(para) { PagePadding = new Thickness(40) };
        var dlg = new System.Windows.Controls.PrintDialog();
        if (dlg.ShowDialog() == true)
            dlg.PrintDocument(((System.Windows.Documents.IDocumentPaginatorSource)doc).DocumentPaginator, "گزارش چک‌ها");
    }
}
